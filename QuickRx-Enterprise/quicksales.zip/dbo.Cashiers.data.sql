SET IDENTITY_INSERT [dbo].[Cashiers] ON
INSERT INTO [dbo].[Cashiers] ([CashierId], [FirstName], [LastName]) VALUES (1, N'Joseph', N'Bartholomew')
SET IDENTITY_INSERT [dbo].[Cashiers] OFF
