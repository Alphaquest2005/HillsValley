﻿using System.Linq;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Unity;
using PrismMVVMLibrary;
using RMSDataAccessLayer;
using System.ComponentModel;
using Microsoft.Practices.Prism.Regions;
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System;
using System.Data.Entity;
using System.Windows.Data;
using System.Printing;
using SUT.PrintEngine.Utils;
using System.Windows.Media;
using QuickBooks;
using System.Data.Objects;
using System.Data;
//using System.Data.Entity;
using EmailLogger;
using System.Data.Entity.Validation;
using System.Data.Objects.DataClasses;



namespace SalesRegion
{
    public class SalesVM : ViewModelBase
    {
        private readonly IUnityContainer container;
        private readonly IEventAggregator eventAggregator;




        //+ Example Command
        public DelegateCommand ExampleCommand { get; set; }

        IRegionManager regionManager;


        public static RMSModel rms = new RMSModel();
        public static Cashier _cashierEx;
        Cashier ca;
        Batch batch; Station station;

        public Cashier CashierEx
        {
            get
            {
                return _cashierEx;

            }
            set
            {
                _cashierEx = value;
                RaisePropertyChanged(() => CashierEx);
            }

        }

        public ApplicationMode ApplicationMode { get; set; }

        [MyExceptionHandlerAspect]
        public SalesVM(IUnityContainer container, IEventAggregator eventAggregator, IRegionManager regionManager)
        {
            this.regionManager = regionManager;
            this.container = container;
            this.eventAggregator = eventAggregator;

            ApplicationMode = SalesRegion.ApplicationMode.Pharmacy;

            //+ Example of run time data vs. design time data (Design data goes in in SalesVMDesign.cs)
            //set runtime to new transaction
            //if (IsInDesignMode == false)
            //{



            // get the current cashier to add it

            StartUp();
            //CreateNewTransaction<TransactionBase>();
            //transactionData.TransactionEntries.Add(new TicketEntry());

            staticPropertyChanged += SalesVM_staticPropertyChanged;

        }


        private void SalesVM_staticPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "TransactionData")
            {
                Set_TransactionData(transactionData);
            }
            if (e.PropertyName == "ShowInactiveItems")
            {
                TransactionData = transactionData;
                UpdateSearchList();
            }
            RaisePropertyChanged(e.PropertyName);
        }


        [MyExceptionHandlerAspect]
        private void StartUp()
        {
            ca = rms.Persons.OfType<Cashier>().Where(x => x.Id == CashierEx.Id).FirstOrDefault();


            station = (from s in rms.Stations
                       where s.MachineName == Environment.MachineName
                       select s).FirstOrDefault();

            batch = (from b in rms.Batches
                     where b.StationId == station.StationId && b.Status == "Open"
                     select b).FirstOrDefault();

            LoadData();

            UpdateSearchList();
            UpdateQBItems();
        }

        [MyExceptionHandlerAspect]
        private void LoadData()
        {
            try
            {
                rms.Item.Where(x => x.QBItemListID != null).Load();
                rms.QBInventoryItems.Load();
                rms.Persons.Load();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }






        [MyExceptionHandlerAspect]
        public void CloseTransaction<T>() where T : TransactionBase
        {
            TransactionData.CloseBatchId = batch.BatchId;
            TransactionData.OpenClose = false;
        }

        [MyExceptionHandlerAspect]
        public void CreateNewTransaction<T>() where T : TransactionBase
        {
            TransactionBase txn;
            if (typeof(T) == typeof(TransactionBase))
            {
                txn = rms.CreateObject<Transaction>();
            }
            else
            {

                txn = rms.CreateObject<T>();
            }

            //create a dummy and save it then deep copy to new type and don't save


            //if (TransactionNumber != finaltxn) TransactionNumber = finaltxn;
            //
            txn.BatchId = batch.BatchId;
            txn.StationId = station.StationId;
            txn.CashierId = ca.Id;
            txn.StoreCode = station.Store.StoreCode;
            txn.Time = DateTime.Now;
            txn.Station = station;
            txn.Cashier = ca;
            txn.OpenClose = true;
            if (ca.Role == "Pharmacist")
                txn.Pharmacist = ca;
            rms.TransactionBase.AddObject(txn);
            // rms.Attach(txn);
            txn.TenderEntryEx.Add(new TenderEntryEx());

            //get last number used in transaction to create the txn number

            TransactionData = txn;


            //################# Can't always save new transaction because of required fields

            txn.TransactionNumber = CreateTxnNumber(txn);
            // SaveTransaction();
            // txn.TransactionNumber = CreateTxnNumber(txn);

            // SaveTransaction();
            //TransactionData.Cashier = ca;
        }

        [MyExceptionHandlerAspect]
        public T CreateNewEntity<T>() where T : class
        {
            T obj = rms.CreateObject<T>();

            return obj;
        }

        [MyExceptionHandlerAspect]
        private string CreateTxnNumber(TransactionBase txn)
        {
            BarCodes.UPCA.cUPCA barcode = new BarCodes.UPCA.cUPCA();
            string txnnumber = (station.Store.TransactionSeed + (txn.TransactionId - station.Store.SeedTransaction)).ToString().PadLeft(11, '0');
            string finaltxn = txnnumber + barcode.GetCheckSum(txnnumber).ToString();
            return finaltxn;
        }

        [MyExceptionHandlerAspect]
        public Boolean SaveTransaction()
        {
            try
            {


                SaveDatabase();

                var txnlist = (from t in rms.TransactionBase
                               where t.TransactionNumber == "000000000000"
                               select t);
                foreach (TransactionBase txn in txnlist)
                {
                    txn.TransactionNumber = CreateTxnNumber(txn);
                }



                SaveDatabase();

                UpdateSearchList();
                return true;
            }
            catch (OptimisticConcurrencyException oce)
            {
                foreach (var item in oce.StateEntries)
                {
                    if (item.State == EntityState.Deleted)
                    {
                        rms.Detach(item.Entity);
                    }
                    else
                    {
                        rms.Refresh(RefreshMode.StoreWins, item);
                        SaveTransaction();
                    }
                }
                return false;
            }
            catch (UpdateException ue)
            {


                foreach (ObjectStateEntry item in ue.StateEntries)
                {
                    if (item.State == EntityState.Added || item.State == EntityState.Deleted)
                    {
                        rms.Detach(item.Entity);
                    }
                    else
                    {
                        rms.DeleteObject(item.Entity);
                    }

                    SaveTransaction();
                    return false;
                }
                return true;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message + " | " + e.StackTrace);
                rms.Dispose();
                rms = new RMSModel();
                TransactionData = null;
                StartUp();
                return false;
            }

        }

        [MyExceptionHandlerAspect]
        public void DiscardChanges()
        {

            rms.Dispose();
            rms = new RMSModel();
            StartUp();
        }


        //+ ToDo: Replace this with your own data fields
        TransactionBase ptran;
        public static RMSDataAccessLayer.TransactionBase transactionData;
        [MyExceptionHandlerAspect]
        public RMSDataAccessLayer.TransactionBase TransactionData
        {
            get { return transactionData; }
            set
            {
                if (!object.Equals(transactionData, value))
                {
                    Set_TransactionData(value);
                }
            }
        }
        [MyExceptionHandlerAspect]
        private void Set_TransactionData(TransactionBase value)
        {

            ptran = transactionData;
            // rms.Attach(value);



            transactionData = value;

            ObjectStateEntry ops;

            if (transactionData != null && rms.ObjectStateManager.TryGetObjectStateEntry(transactionData, out ops) == false)
            {
                transactionData = rms.TransactionBase.FirstOrDefault(x => x.TransactionId == transactionData.TransactionId);
            }
            if (transactionData != null)
            {
                this.regionManager.Regions["HeaderRegion"].Context = transactionData;

            }
            RaisePropertyChanged(() => TransactionData);

        }


        private ListCollectionView _qbitems;
        [MyExceptionHandlerAspect]
        public ListCollectionView QBItems
        {
            get { return _qbitems; }

        }

        [MyExceptionHandlerAspect]
        public void UpdateQBItems()
        {
            _qbitems = new ListCollectionView(rms.QBInventoryItems.OrderBy(itm => itm.ItemName).ToList<QBInventoryItem>());
            RaisePropertyChanged("QBItems");

        }

        private static ObservableCollection<object> _csv;
        [MyExceptionHandlerAspect]
        public ObservableCollection<object> SearchList
        {
            get { return _csv; }

        }

        public static ObservableCollection<Cashier> _pharmacists;
        [MyExceptionHandlerAspect]
        public ObservableCollection<Cashier> Pharmacists
        {
            get
            {


                rms.CashierLogs.MergeOption = MergeOption.OverwriteChanges;

                var lst = new ObservableCollection<Cashier>(rms.CashierLogs.Where(x => x.Status == "LogIn")
                                                                        .AsEnumerable()
                                                                        .Where(x => x.Cashier.Role == "Pharmacist")

                                                                        .Select(x => x.Cashier).Distinct());

                if (TransactionData != null)
                {
                    //if (TransactionData.Pharmacist != null && lst.Contains(TransactionData.Pharmacist) == false)
                    //{
                    //    //TransactionData.Pharmacist = null;
                    //}
                    //else
                    //{


                    //    //if (ca.Role == "Pharmacist")
                    //    //    TransactionData.Pharmacist = ca;
                    //}
                }
                _pharmacists = lst;
                RaisePropertyChanged(() => CashierEx);
                RaisePropertyChanged(() => TransactionData.Pharmacist);
                return _pharmacists;
            }

        }

        [MyExceptionHandlerAspect]
        public void DownloadQBItems()
        {
            QBPOS pos = new QBPOS();
            TrackableCollection<ItemInventoryRet> itms = pos.GetInventoryItemQuery();

            if (itms != null)
            {
                //clear qbitems
                //foreach (var item in rms.QBInventoryItems)
                //{
                //    rms.QBInventoryItems.DeleteObject(item);
                //}
                //rms.SaveChanges();
                var itmcnt = 0;

                List<Item> clst = rms.Item.Where(x => x.QBItemListID != null).ToList();

                foreach (var item in itms)
                {

                    if (itmcnt % 100 == 0)
                    {
                        SaveDatabase();
                    }

                    QBInventoryItem i = rms.QBInventoryItems.FirstOrDefault(x => x.ListID == item.ListID);
                    if (i == null)
                    {
                        i = new QBInventoryItem();
                        rms.QBInventoryItems.AddObject(i);
                    }
                    i.ItemName = item.Desc1;
                    i.ItemDesc2 = item.Desc2;
                    i.ListID = item.ListID;
                    i.Size = item.Size;
                    i.TaxCode = item.TaxCode;
                    i.ItemNumber = System.Convert.ToInt16(item.ItemNumber);
                    i.Price = System.Convert.ToDouble(item.Price1);
                    i.Quantity = System.Convert.ToDouble(item.QuantityOnHand);



                    Item itm = clst.FirstOrDefault(x => x.QBItemListID == i.ListID);
                    if (itm == null)
                    {
                        itm = new Medicine();
                        itm.Description = i.ItemName;
                        (itm as Medicine).SuggestedDosage = "Take as Directed by your Doctor";
                        itm.Inactive = false;
                        rms.Item.AddObject(itm);

                    }

                    if (itm != null)
                    {
                        itm.QBItemListID = i.ListID;
                        itm.QBInventoryItem = i;

                        //if(i.Items.Contains(itm) == false)
                        //i.Items.Add(itm);

                        itm.Description = i.ItemName;
                        itm.Price = System.Convert.ToDecimal(i.Price);
                        itm.Quantity = Convert.ToDouble(i.Quantity);
                        if (i.TaxCode == "VAT")
                        {
                            itm.SalesTax = (Decimal).15;
                        }
                        else
                        {
                            itm.SalesTax = (Decimal)0;
                        }
                    }

                    itmcnt += 1;
                }
                SaveDatabase();
                UpdateQBItems();
                UpdateSearchList();
                MessageBox.Show("QuickBooks Inventory Downloaded");

            }




        }

        [MyExceptionHandlerAspect]
        public void UpdateSearchList()
        {
            CompositeCollection cc = CreateSearchList();


            _csv = new ObservableCollection<Object>();
            foreach (var item in cc)
            {
                _csv.Add(item);
            }
            RaisePropertyChanged(() => SearchList);
            OnStaticPropertyChanged("SearchList");
        }

        public void UpdateSearchList(string filterText)
        {
            CompositeCollection cc = CreateSearchList(filterText);


            _csv = new ObservableCollection<Object>();
            foreach (var item in cc)
            {
                _csv.Add(item);
            }
            RaisePropertyChanged(() => SearchList);
            OnStaticPropertyChanged("SearchList");
        }

        public void GetSearchResults(string filterText)
        {
            UpdateSearchList(filterText);
        }

        [MyExceptionHandlerAspect]
        private CompositeCollection CreateSearchList()
        {
            CompositeCollection cc = new CompositeCollection();

            AddSearchItems(cc);
            AddCustomers(cc);
            if (ApplicationMode == SalesRegion.ApplicationMode.Ticket) AddPass(cc);
            AddTransaction(cc);
            AddInventory(cc);


            return cc;
        }

        [MyExceptionHandlerAspect]
        private CompositeCollection CreateSearchList(string filterText)
        {
            CompositeCollection cc = new CompositeCollection();

            AddSearchItems(cc);
            AddCustomers(cc, filterText);
            double t = 0;
            if (double.TryParse(filterText, out t))
            {
                AddTransaction(cc, filterText);
            }

            AddInventory(cc, filterText);


            return cc;
        }

        [MyExceptionHandlerAspect]
        private void AddSearchItems(CompositeCollection cc)
        {
            SearchItem b = new SearchItem();
            b.SearchObject = new RMSDataAccessLayer.Transactionlist();
            b.SearchCriteria = "Transaction History";
            b.DisplayName = "Transaction History";
            cc.Add(b);

            if (ApplicationMode == SalesRegion.ApplicationMode.Pharmacy)
            {
                SearchItem p = new SearchItem();
                p.SearchObject = null;
                p.SearchCriteria = "Add Patient";
                p.DisplayName = "Add Patient";
                cc.Add(p);

                SearchItem d = new SearchItem();
                d.SearchObject = null;
                d.SearchCriteria = "Add Doctor";
                d.DisplayName = "Add Doctor";
                cc.Add(d);

                SearchItem i = new SearchItem();
                i.SearchObject = null;
                i.SearchCriteria = "Add Medicine";
                i.DisplayName = "Add Medicine";
                cc.Add(i);
            }

        }

        [MyExceptionHandlerAspect]
        private void AddPass(CompositeCollection cc)
        {
            foreach (var pass in rms.Pass)
            {
                cc.Add(pass);
            }
        }

        [MyExceptionHandlerAspect]
        private void AddTransaction(CompositeCollection cc)
        {
            try
            {


                switch (ApplicationMode)
                {
                    case ApplicationMode.Ticket:
                        var opnlst = (from trn in rms.TransactionEntryBase.OfType<TicketEntry>()
                                      //where trn.EndDateTime == null
                                      orderby trn.TransactionTime

                                      select trn.Transaction);


                        foreach (var trns in opnlst)
                        {
                            cc.Add(trns);
                        }
                        break;
                    case ApplicationMode.Pharmacy:
                        // right now any prescriptions
                        foreach (var trns in rms.TransactionBase.OfType<Prescription>().OrderBy(t => t.Time).Take(100))
                        {
                            cc.Add(trns);
                        }
                        foreach (var trns in rms.TransactionBase.OfType<QuickPrescription>().OrderBy(t => t.Time).Take(100))
                        {
                            cc.Add(trns);
                        }

                        break;
                    case ApplicationMode.POS:
                        foreach (var trns in rms.TransactionBase.OfType<Transaction>().OrderBy(t => t.Time))
                        {
                            cc.Add(trns);
                        }

                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [MyExceptionHandlerAspect]
        private void AddTransaction(CompositeCollection cc, string filterText)
        {
            try
            {


                switch (ApplicationMode)
                {
                    case ApplicationMode.Ticket:
                        var opnlst = (from trn in rms.TransactionEntryBase.OfType<TicketEntry>()
                                      //where trn.EndDateTime == null
                                      orderby trn.TransactionTime

                                      select trn.Transaction);


                        foreach (var trns in opnlst)
                        {
                            cc.Add(trns);
                        }
                        break;
                    case ApplicationMode.Pharmacy:
                        // right now any prescriptions
                        foreach (var trns in rms.TransactionBase.OfType<Prescription>().Where(x => x.TransactionNumber.Contains(filterText)).OrderBy(t => t.Time).Take(100))
                        {
                            cc.Add(trns);
                        }
                        foreach (var trns in rms.TransactionBase.OfType<QuickPrescription>().Where(x => x.TransactionNumber.Contains(filterText)).OrderBy(t => t.Time).Take(100))
                        {
                            cc.Add(trns);
                        }

                        break;
                    case ApplicationMode.POS:
                        foreach (var trns in rms.TransactionBase.OfType<Transaction>().OrderBy(t => t.Time))
                        {
                            cc.Add(trns);
                        }

                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [MyExceptionHandlerAspect]
        private void AddCustomers(CompositeCollection cc)
        {
            switch (ApplicationMode)
            {
                case ApplicationMode.Ticket:
                    break;
                case ApplicationMode.Pharmacy:
                    foreach (var cus in rms.Persons.OfType<Patient>().Take(100).AsEnumerable().OrderBy(x => x.DisplayName))
                    {
                        cc.Add(cus);
                    }

                    foreach (var cus in rms.Persons.OfType<Doctor>().Take(100).AsEnumerable().OrderBy(x => x.DisplayName))
                    {
                        cc.Add(cus);
                    }
                    break;
                case ApplicationMode.POS:
                    foreach (var cus in rms.Persons.OfType<Customers>().AsEnumerable().OrderBy(x => x.DisplayName))
                    {
                        cc.Add(cus);
                    }
                    break;
                default:
                    break;
            }

        }

        [MyExceptionHandlerAspect]
        private void AddCustomers(CompositeCollection cc, string filterText)
        {
            switch (ApplicationMode)
            {
                case ApplicationMode.Ticket:
                    break;
                case ApplicationMode.Pharmacy:

                    foreach (var cus in rms.Persons.OfType<Patient>().Where(x => (x.FirstName + " " + x.LastName).Contains(filterText)).Take(100))//
                    {
                        cc.Add(cus);
                    }

                    foreach (var cus in rms.Persons.OfType<Doctor>().Where(x => ("Dr. " + " " + x.FirstName.Replace("Dr", "").Replace("Dr.", "") + " " + x.LastName + " " + x.Code).Contains(filterText)).Take(100))
                    {
                        cc.Add(cus);
                    }
                    break;
                case ApplicationMode.POS:
                    foreach (var cus in rms.Persons.OfType<Customers>().AsEnumerable().OrderBy(x => x.DisplayName))
                    {
                        cc.Add(cus);
                    }
                    break;
                default:
                    break;
            }

        }


        private static bool _showInactiveItems = false;
        [MyExceptionHandlerAspect]
        public static bool ShowInactiveItems
        {
            get
            {
                return _showInactiveItems;
            }
            set
            {
                _showInactiveItems = value;
                SalesVM.OnStaticPropertyChanged("ShowInactiveItems");
            }

        }

        [MyExceptionHandlerAspect]
        private void AddInventory(CompositeCollection cc)
        {
            try
            {



                switch (ApplicationMode)
                {
                    case ApplicationMode.Ticket:
                        foreach (var itm in rms.Item.OfType<TicketItem>())
                        {
                            cc.Add(itm);
                        }
                        break;
                    case ApplicationMode.Pharmacy:

                        List<RMSDataAccessLayer.Medicine> itms = rms.Item.OfType<Medicine>().Where(x => x.QBItemListID != null && (x.Inactive == null || (x.Inactive != null && x.Inactive == _showInactiveItems))).AsEnumerable().OrderBy(x => x.DisplayName).ToList(); //QBItemListID != null

                        foreach (var itm in itms.Take(100))
                        {
                            cc.Add(itm);
                        }

                        foreach (var itm in rms.Item.OfType<StockItem>().Take(100))
                        {
                            cc.Add(itm);
                        }

                        break;
                    case ApplicationMode.POS:
                        foreach (var itm in rms.Item.OfType<StockItem>())
                        {
                            cc.Add(itm);
                        }
                        break;

                    default:
                        break;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }


        }

        [MyExceptionHandlerAspect]
        private void AddInventory(CompositeCollection cc, string filterText)
        {
            try
            {



                switch (ApplicationMode)
                {
                    case ApplicationMode.Ticket:
                        foreach (var itm in rms.Item.OfType<TicketItem>())
                        {
                            cc.Add(itm);
                        }
                        break;
                    case ApplicationMode.Pharmacy:

                        List<RMSDataAccessLayer.Medicine> itms = rms.Item.OfType<Medicine>().Where(x => x.Description.Contains(filterText) && x.QBItemListID != null && (x.Inactive == null || (x.Inactive != null && x.Inactive == _showInactiveItems))).Take(100).AsEnumerable().OrderBy(x => x.DisplayName).ToList(); //QBItemListID != null

                        foreach (var itm in itms)
                        {
                            cc.Add(itm);
                        }

                        foreach (var itm in rms.Item.OfType<StockItem>().Where(x => x.Description.Contains(filterText)).Take(100))
                        {
                            cc.Add(itm);
                        }

                        break;
                    case ApplicationMode.POS:
                        foreach (var itm in rms.Item.OfType<StockItem>())
                        {
                            cc.Add(itm);
                        }
                        break;

                    default:
                        break;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }


        }

        [MyExceptionHandlerAspect]
        public void AddCustomerToTransaction(RMSDataAccessLayer.Customers cus)
        {

            TransactionData.CustomerId = cus.Id;
        }

        [MyExceptionHandlerAspect]
        public void ProcessSearchListItem(object SearchItem)
        {
            if (SearchItem != null)
            {
                if (typeof(RMSDataAccessLayer.SearchItem) == SearchItem.GetType())
                {
                    DoSearchItem(SearchItem as RMSDataAccessLayer.SearchItem);
                }

                if (typeof(RMSDataAccessLayer.Doctor) == SearchItem.GetType())
                {
                    AddDoctorToTransaction(SearchItem as Doctor);
                }

                if (typeof(RMSDataAccessLayer.Patient) == SearchItem.GetType())
                {
                    AddPatientToTransaction(SearchItem as Patient);
                }




                if (typeof(RMSDataAccessLayer.Customers) == SearchItem.GetType())
                {
                    AddCustomerToTransaction(SearchItem as Customers);
                }
                if (typeof(RMSDataAccessLayer.Pass) == SearchItem.GetType())
                {
                    //save transaction
                    // SaveTransaction();

                    //create new transaction
                    CreateNewTransaction<Ticket>();
                    // get ticket item from inventory
                    var itm = (from i in rms.Item
                               where i.Description == "Ticket"
                               select i).FirstOrDefault();
                    //create new ticket

                    AddPassToTransaction(SearchItem as Pass);

                    if (TransactionData.Status == null)
                    {
                        InsertItemTransactionEntry((Item)itm);
                    }
                    //save transaction
                    SaveTransaction();



                }
                if (typeof(RMSDataAccessLayer.Item).IsInstanceOfType(SearchItem))
                {
                    NewItemTransaction(SearchItem as Item);
                }
                if (typeof(TransactionBase).IsAssignableFrom(SearchItem.GetType()))
                {
                    GoToTransaction((TransactionBase)SearchItem);
                }

            }
        }

        [MyExceptionHandlerAspect]
        private void AddPatientToTransaction(Patient patient)
        {
            if (!typeof(Prescription).IsInstanceOfType(transactionData))
            {
                SaveTransaction();
                CreateNewTransaction<Prescription>();

            }
            ((Prescription)TransactionData).PatientId = patient.Id;
            ((Prescription)TransactionData).Patient = patient;
            ApplyPatientDiscount();
            //((Prescription)TransactionData).Patient = patient;
        }

        [MyExceptionHandlerAspect]
        private void ApplyPatientDiscount(TransactionEntryBase trn = null)
        {
            if (typeof(Prescription).IsInstanceOfType(TransactionData) && ((Prescription)TransactionData).Patient != null)
            {
                var p = ((Prescription)TransactionData).Patient;

                if (trn == null)
                {
                    foreach (var te in TransactionData.TransactionEntries)
                    {
                        te.Discount = Convert.ToDecimal(p.Discount);
                    }
                }
                else
                {
                    trn.Discount = Convert.ToDecimal(p.Discount);
                }

            }
        }

        [MyExceptionHandlerAspect]
        private void AddDoctorToTransaction(Doctor doctor)
        {
            // only prescriptions can have doctors


            if (!typeof(Prescription).IsInstanceOfType(transactionData))
            {
                SaveTransaction();
                CreateNewTransaction<Prescription>();

            }
            ((Prescription)TransactionData).DoctorId = doctor.Id;
            //((Prescription)TransactionData).Doctor = doctor;


        }


        [MyExceptionHandlerAspect]
        private void DoSearchItem(SearchItem searchItem)
        {
            if (rms.TransactionBase.GetType() == searchItem.GetType())
            {

            }
        }

        [MyExceptionHandlerAspect]
        private void GoToTransaction(TransactionBase trn)
        {
            TransactionData = trn;

        }

        [MyExceptionHandlerAspect]
        public void GoToTransaction(int TransactionId)
        {
            TransactionBase ntrn;
            ntrn = (from t in rms.TransactionBase
                    where t.TransactionId == TransactionId
                    orderby t.Time descending
                    select t).FirstOrDefault();
            rms.Attach(ntrn);
            TransactionData = ntrn;
        }

        [MyExceptionHandlerAspect]
        public void GoToPreviousTransaction()
        {
            TransactionBase ptrn;
            if (TransactionData == null)
            {
                ptrn = (from t in rms.TransactionBase
                        orderby t.Time descending
                        select t).FirstOrDefault();
            }
            else
            {
                if (TransactionData.TransactionId != 0)
                {
                    ptrn = (from t in rms.TransactionBase
                            where t.TransactionId < TransactionData.TransactionId
                            orderby t.Time descending
                            select t).FirstOrDefault();
                }
                else
                {
                    ptrn = (from t in rms.TransactionBase
                            orderby t.Time descending
                            select t).FirstOrDefault();
                }
            }
            if (ptrn != null)
            {
                rms.Attach(ptrn);
                TransactionData = ptrn;
            }
            else
            {
                MessageBox.Show("No previous transaction");
            }
        }

        [MyExceptionHandlerAspect]
        private void AddPassToTransaction(RMSDataAccessLayer.Pass pass)
        {

            foreach (var trn in pass.Ticket)
            {
                foreach (TicketEntry tic in trn.TransactionEntries)
                {
                    if (tic.EndDateTime == null)
                    {
                        GoToTransaction(trn);
                        return;
                    }
                }
            }

            ((Ticket)TransactionData).PassId = pass.PassId;
        }

        [MyExceptionHandlerAspect]
        private void InsertItemTransactionEntry(RMSDataAccessLayer.Item itm)
        {

            if (TransactionData.CurrentTransactionEntry == null)
            {
                if (ApplicationMode == SalesRegion.ApplicationMode.Ticket)//typeof(TicketItem).IsInstanceOfType(itm)
                {
                    CreateTransactionEntry<TicketEntry>();
                }
                else if (ApplicationMode == SalesRegion.ApplicationMode.Pharmacy)//typeof(Medicine).IsInstanceOfType(itm)
                {
                    CreateTransactionEntry<PrescriptionEntry>();
                }
                else
                {
                    CreateTransactionEntry<TransactionEntry>();
                }
            }

            if (itm.ItemId == 0) throw new Exception("This is a new created item, should be existing item");

            if (TransactionData.CurrentTransactionEntry == null) return;
            TransactionData.CurrentTransactionEntry.ItemId = itm.ItemId;
            TransactionData.CurrentTransactionEntry.Price = itm.Price;
            if (typeof(Medicine).IsInstanceOfType(itm))
            {
                Medicine med = itm as Medicine;
                if (med.QBInventoryItem != null)
                {
                    if (med.QBInventoryItem.TaxCode == "VAT")
                    {
                        TransactionData.CurrentTransactionEntry.SalesTaxPercent = (Decimal).15;
                        TransactionData.CurrentTransactionEntry.Taxable = true;
                    }
                    else
                    {
                        TransactionData.CurrentTransactionEntry.SalesTaxPercent = 0;
                        TransactionData.CurrentTransactionEntry.Taxable = false;
                    }
                }
                else
                {
                    if (itm.SalesTax == null)
                    {
                        TransactionData.CurrentTransactionEntry.SalesTaxPercent = (Decimal).15;
                    }
                    else
                    {
                        TransactionData.CurrentTransactionEntry.SalesTaxPercent = (Decimal)itm.SalesTax;
                    }
                }
            }
            else
            {
                TransactionData.CurrentTransactionEntry.SalesTaxPercent = (Decimal)itm.SalesTax; //(Decimal).15;
            }
            TransactionData.CurrentTransactionEntry.Item = itm;



            // SaveTransaction();
        }

        [MyExceptionHandlerAspect]
        public void CreateTransactionEntry()
        {
            switch (ApplicationMode)
            {
                case SalesRegion.ApplicationMode.Pharmacy:
                    CreateTransactionEntry<PrescriptionEntry>();
                    break;
                case SalesRegion.ApplicationMode.Ticket:

                    CreateTransactionEntry<TicketEntry>();
                    break;

                case SalesRegion.ApplicationMode.POS:
                    CreateTransactionEntry<TransactionEntry>();
                    break;
            }
        }

        [MyExceptionHandlerAspect]
        public void CreateTransactionEntry<T>() where T : TransactionEntryBase
        {
            if(AutoCreateOldTransactions() == false) return;


            T tkt = rms.TransactionEntryBase.CreateObject<T>();
            rms.TransactionEntryBase.AddObject(tkt);

            TransactionData.TransactionEntries.Add(tkt);

            ApplyPatientDiscount(tkt);

            //ItemEditor.ItemsSource = new List<RMSDataAccessLayer.TransactionEntryBase> {Transaction.CurrentTransactionEntry};
            TransactionData.CurrentTransactionEntry = tkt;
        }

        private bool AutoCreateOldTransactions()
        {
            if (TransactionData == null) return false;
            if (TransactionData.Time.Date != DateTime.Now.Date)
            {
                var res = MessageBox.Show("Modifying old transactions is not allowed! Do you want to create a New Transaction?", "Can't Modify Old Transaction", MessageBoxButton.YesNo);
                if (res == MessageBoxResult.Yes)
                {
                   TransactionData = CopyCurrentTransaction();
                    return true;
                }
                if (res == MessageBoxResult.No) return false;
            }
            return true;
        }

        [MyExceptionHandlerAspect]
        public void DeleteTransactionEntry<T>(TransactionEntryBase dtrn) where T : TransactionEntryBase
        {
            try
            {
                if (AutoCreateOldTransactions() == false) return;

                if (dtrn == null) return;
                TransactionEntryBase d = null;
                ObjectStateEntry ops = null;

                if (dtrn != null && dtrn.EntityState != EntityState.Added && rms.ObjectStateManager.TryGetObjectStateEntry(dtrn, out ops) == false)
                {
                    d = rms.TransactionEntryBase.FirstOrDefault(x => x.TransactionEntryId == dtrn.TransactionEntryId);
                }

                if (ops != null)
                {
                    d = ops.Entity as TransactionEntryBase;
                }

                if (dtrn.EntityState == EntityState.Added)
                {
                    d = rms.ObjectStateManager.GetObjectStateEntries(EntityState.Added)
                                  .Where(x => x.Entity == dtrn)
                                  .Select(entry => entry.Entity)
                                  .OfType<TransactionEntryBase>()
                                  .FirstOrDefault();
                }


                if (d == null)
                {
                    rms.TransactionEntryBase.Attach(dtrn);
                    d = dtrn;
                };
                TransactionData.TransactionEntries.Remove(d);
                rms.TransactionEntryBase.DeleteObject(d);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [MyExceptionHandlerAspect]
        public void DeleteCurrentTransaction()
        {
            if (MessageBox.Show("Are you sure you want to delete?", "Delete Current Transaction", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                //foreach (TransactionEntryBase item in TransactionData.TransactionEntries.ToList())
                //{
                //    TransactionData.TransactionEntries.Remove(item);

                //    rms.TransactionEntryBase.DeleteObject(item);
                //}
                if (TransactionData.Time.Date != DateTime.Now.Date)
                {
                    var res = MessageBox.Show("Modifying old transactions is not allowed!", "Can't Modify Old Transaction");
                    return;
                }



                rms.TransactionBase.DeleteObject(TransactionData);
                SaveDatabase();
                GoToPreviousTransaction();
            }

        }

        [MyExceptionHandlerAspect]
        public TransactionBase CopyCurrentTransaction()
        {
            dynamic newt = null;
            if (TransactionData == null)
            {
                MessageBox.Show("Please select transaction again to continue...");
                return null;
            }
            if (TransactionData.GetType() == typeof(Prescription))
            {
                newt = Common.CopyEntity<Prescription>(rms, TransactionData as Prescription, false);
            }

            if (TransactionData.GetType() == typeof(QuickPrescription))
            {
                newt = Common.CopyEntity<QuickPrescription>(rms, TransactionData as QuickPrescription, false);
            }
            newt.TransactionNumber = CreateTxnNumber(newt);
            newt.ReferenceNumber = "";
            newt.Time = DateTime.Now;
            newt.Cashier = ca;
            if (ca.Role == "Pharmacist")
                newt.Pharmacist = ca;

            foreach (PrescriptionEntry item in TransactionData.TransactionEntries)
            {
                newt.TransactionEntries.Add((TransactionEntryBase)Common.CopyEntity<PrescriptionEntry>(rms, item, false));

            }

            //var key = rms.CreateEntityKey("TransactionBase", newt);
            //ObjectStateEntry ose;
            //if (rms.ObjectStateManager.TryGetObjectStateEntry(key, out ose))
            //{
            //    var entity = (TransactionBase)ose.Entity;
            //    rms.Detach(entity);
            //}
            rms.TransactionBase.AddObject(newt);
            return newt;
        }

        [MyExceptionHandlerAspect]
        public void CopyPrescription()
        {
            TransactionBase newt = CopyCurrentTransaction();
            foreach (var item in newt.TransactionEntries.ToList())
            {
                newt.TransactionEntries.Remove(item);
                rms.DeleteObject(item);
            }
            TransactionData = newt;
            SaveTransaction();
        }

        [MyExceptionHandlerAspect]
        public void AutoRepeat()
        {
            TransactionBase newt = CopyCurrentTransaction();
            foreach (PrescriptionEntry item in newt.TransactionEntries.ToList())
            {
                if (item.Repeat == 0)
                {
                    //newt.TransactionEntries.Remove(item);
                    // rms.Detach(item);
                }
                else
                {
                    item.Repeat -= 1;
                }
            }



            // rms.TransactionBase.AddObject(newt);
            TransactionData = newt;
            SaveTransaction();
        }

        [MyExceptionHandlerAspect]
        public void CloseTicket()
        {
            ((TicketEntry)TransactionData.CurrentTransactionEntry).EndDateTimeEx = DateTime.Now;
            //Print Ticket
            SaveTransaction();
        }

        [MyExceptionHandlerAspect]
        public void NewTransaction()
        {
            //save transaction
            // SaveTransaction();

            //create new transaction
            if (TransactionData == null || TransactionData.TransactionEntries.Count != 0)
            {
                switch (ApplicationMode)
                {
                    case ApplicationMode.Ticket:
                        CreateNewTransaction<Ticket>();
                        break;
                    case ApplicationMode.Pharmacy:
                        CreateNewTransaction<Prescription>();
                        if (ca.Role == "Pharamacist")
                            TransactionData.Pharmacist = ca;
                        break;
                    case ApplicationMode.POS:
                        CreateNewTransaction<Transaction>();
                        break;
                    default:
                        CreateNewTransaction<TransactionBase>();
                        break;
                }

            }
            // get ticket item from inventory

            if (ApplicationMode == SalesRegion.ApplicationMode.Ticket) InsertItemTransactionEntry(rms.Item.OfType<TicketItem>().First());

            //save transaction
            SaveTransaction();
            //print ticket
        }

        [MyExceptionHandlerAspect]
        private void NewItemTransaction(Item SearchItem)
        {
            if (TransactionData == null)
            {
                if (ApplicationMode == SalesRegion.ApplicationMode.Ticket) CreateNewTransaction<Ticket>();//typeof(TicketItem).IsInstanceOfType(SearchItem)
                if (ApplicationMode == SalesRegion.ApplicationMode.Pharmacy) CreateNewTransaction<QuickPrescription>();//typeof(Medicine).IsInstanceOfType(SearchItem)
                if (ApplicationMode == SalesRegion.ApplicationMode.POS) CreateNewTransaction<Transaction>();//typeof(StockItem).IsInstanceOfType(SearchItem)
            }
            InsertItemTransactionEntry(SearchItem as Item);
        }

        [MyExceptionHandlerAspect]
        public void Print(ref Grid fwe)
        {
            FrameworkElement f = fwe;
            Print(ref f);
        }

        [MyExceptionHandlerAspect]
        public void Print(ref FrameworkElement fwe)
        {
            if (TransactionData == null) return;
            //LocalPrintServer printserver = new LocalPrintServer();
            PrintServer printserver = new PrintServer(station.PrintServer);


            Size visualSize;
            if (ApplicationMode == SalesRegion.ApplicationMode.Pharmacy)
            {
                visualSize = new Size(288, 2 * 96);// paper size
            }
            else
            {
                visualSize = new Size(fwe.ActualWidth, fwe.ActualHeight);
            }

            DrawingVisual visual = PrintControlFactory.CreateDrawingVisual(fwe, fwe.ActualWidth, fwe.ActualHeight);


            SUT.PrintEngine.Paginators.VisualPaginator page = new SUT.PrintEngine.Paginators.VisualPaginator(visual, visualSize, new Thickness(0, 0, 0, 0), new Thickness(0, 0, 0, 0));
            page.Initialize(false);

            PrintDialog pd = new PrintDialog();
            pd.PrintQueue = printserver.GetPrintQueue(TransactionData.Station.ReceiptPrinterName);

            //  pd.PrintQueue = printserver.GetPrintQueue("TSC TDP-244");
            //  pd.PrintQueue = printServer.GetPrintQueues(new [] {EnumeratedPrintQueueTypes.Shared} );

            //if (pd.ShowDialog()==true)
            //{

            pd.PrintDocument(page, "");
            //}
        }

        [MyExceptionHandlerAspect]
        public void PostQBSale()
        {
            SalesReceipt s = new SalesReceipt();
            s.TxnDate = TransactionData.Time;
            s.TxnState = "1";
            s.Workstation = "02";
            s.StoreNumber = "1";
            s.SalesReceiptNumber = "123";
            s.Discount = "0";

            if (TransactionData == null || string.IsNullOrEmpty(TransactionData.TransactionNumber))
            {
                MessageBox.Show("Invalid Transaction Please Try again");
                return;
            }

            TransPreZeroConverter tz = new TransPreZeroConverter();

            if (typeof(Prescription).IsInstanceOfType(TransactionData))
            {
                Prescription p = transactionData as Prescription;
                string doctor = "";
                string patient = "";
                if (p.Doctor != null)
                {
                    doctor = p.Doctor.DisplayName;
                }
                if (p.Patient != null)
                {
                    patient = p.Patient.ContactInfo;
                    s.Discount = p.Patient.Discount == null ? "" : p.Patient.Discount.ToString();
                }
                s.Comments = String.Format("{0} \n RX#:{1} \n Doctor:{2}", patient, tz.Convert(p.TransactionNumber, typeof(string), null, null), doctor);
            }
            else
            {
                s.Comments = "RX#:" + tz.Convert(TransactionData.TransactionNumber, typeof(string), null, null);
            }

            if (TransactionData == null || string.IsNullOrEmpty(TransactionData.TransactionNumber))
            {
                rms.Refresh(RefreshMode.StoreWins, TransactionData);
                if (TransactionData == null || string.IsNullOrEmpty(TransactionData.TransactionNumber))
                {
                    MessageBox.Show("Invalid Transaction Please Try again");
                    return;
                }
            }

            s.TrackingNumber = tz.Convert(TransactionData.TransactionNumber, typeof(string), null, null).ToString();
            s.Associate = "Dispensary";
            s.SalesReceiptType = "0";



            foreach (var item in TransactionData.TransactionEntries)
            {
                if (item.Item.QBItemListID != null)
                {

                    s.SalesReceiptDetails.Add(new SalesReceiptDetail { ItemListID = item.Item.QBItemListID, QtySold = item.Quantity });//340 
                }
                else
                {
                    MessageBox.Show("Please Link Quickbooks item to dispensary");
                    return;
                }
            }


            QBPOS qb = new QBPOS();
            SalesReceiptRet result = qb.AddSalesReceipt(s);
            if (result != null)
            {
                transactionData.ReferenceNumber = "QB#" + result.SalesReceiptNumber;
            }
        }


        #region INotifyPropertyChanged Members

        public static event PropertyChangedEventHandler staticPropertyChanged;

        public static void OnStaticPropertyChanged(String info)
        {

            if (staticPropertyChanged != null)
            {
                staticPropertyChanged(null, new PropertyChangedEventArgs(info));
            }
        }

        #endregion

        [MyExceptionHandlerAspect]
        internal void DetectChanges()
        {

            SaveDatabase();
            // UpdateSearchList();
        }

        private void SaveDatabase()
        {
            bool dbsuccess = false;
            while (dbsuccess == false)
            {
                dbsuccess = SaveDatabase1();
            }
        }
        [MyExceptionHandlerAspect]
        public static bool SaveDatabase1()
        {
            try
            {
                rms.SaveChanges();
                return true;
            }
            catch (OptimisticConcurrencyException oce)
            {
                foreach (var item in oce.StateEntries)
                {
                    if (item.State == EntityState.Deleted)
                    {
                        ObjectStateEntry entry;
                        if (rms.ObjectStateManager.TryGetObjectStateEntry(item.Entity, out entry))
                        {
                            rms.Detach(entry.Entity);
                        }
                    }
                    else
                    {
                        ObjectStateEntry entry;
                        if (rms.ObjectStateManager.TryGetObjectStateEntry(item.Entity, out entry))
                        {
                            if (entry.EntityKey != null)
                            {
                                rms.Refresh(RefreshMode.StoreWins, item);
                            }
                        }
                        //  SaveDatabase();
                    }


                }
                return false;
                //db.Refresh(RefreshMode.StoreWins, oce.StateEntries.Select(e => e.Entity));     
                //SaveDatabase();

            }
            catch (UpdateException ue)
            {


                foreach (ObjectStateEntry item in ue.StateEntries)
                {
                    if (item.State == EntityState.Added || item.State == EntityState.Deleted)
                    {
                        rms.Detach(item.Entity);
                    }
                    else
                    {
                        rms.DeleteObject(item.Entity);
                    }

                    //  SaveDatabase();
                    return false;
                }
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
            catch (InvalidOperationException ie)
            {
                return false;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }


    }
}
