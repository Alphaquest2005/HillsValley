﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Unity;
using PrismMVVMLibrary;
using Microsoft.Practices.Prism.Regions;
using RMSDataAccessLayer;
using Microsoft.Practices.Prism;
using System.Data.Entity;
using System.Collections.ObjectModel;
using EmailLogger;

namespace LeftRegion
{
    public class SuppVM : ViewModelBase
    {
        private readonly IEventAggregator eventAggregator;
        private readonly IUnityContainer container;

        public SuppVM(IUnityContainer container, IEventAggregator eventAggregator, IRegionManager regionManager)
        {
            //+ Example of run time data vs. design time data (Design data goes in in TransactionVMDesign.cs)
           // TransactionData =  regionManager..Regions["HeaderRegion"].Context as RMSDataAccessLayer.Transaction;
            this.regionManager = regionManager;
            this.container = container;
            this.eventAggregator = eventAggregator;

        }
        IRegionManager regionManager;
      

        static string _searchText;
        [MyExceptionHandlerAspect]
        public string SearchText
        {
            get
            {
                return _searchText;
            }
            set
            {
                try
                {
                    _searchText = value;
                    RaisePropertyChanged(() => SearchText);
                    SearchPrescriptions();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
        }

        [MyExceptionHandlerAspect]
        public void AutoRepeat()
        {
            SalesRegion.SalesView.salesvm.AutoRepeat();
        }

        [MyExceptionHandlerAspect]
        public void CopyPrescription()
        {
            SalesRegion.SalesView.salesvm.CopyPrescription();
        }

        [MyExceptionHandlerAspect]
        private void SearchPrescriptions()
        {
            try
            {
                using (RMSModel db = new RMSModel())//   SalesRegion.SalesVM.rms;
                {
                    db.Item.ToList();


                    List<RMSDataAccessLayer.Prescription> lst = db.TransactionBase.OfType<Prescription>()
                                                                .Include("Patient")
                                                                .Include("Doctor")
                                                                .Include("TransactionEntries")
                                                                .Include("TransactionEntries.Item")
                                                                .Include("Cashier")
                                                                .Include("Batch")
                                                                .Include("Station")
                                                                
                                                              
                                                                .AsEnumerable().ToList();

                    var layers = SearchText.ToUpper().Split(':');

                    if (layers[0] != "")
                    {
                        foreach (var item in layers[0].ToUpper().Split(' '))
                        {
                            var nlst = lst.Where(x => x.SearchCriteria.ToUpper().Contains(item) == true).ToList();
                            //if (nlst.Any())
                            lst = nlst;

                        }
                    }
                    if (layers.Count() > 1 && layers[1] != "")
                    {
                        var plst = // db.TransactionBase.OfType<Prescription>()
                                        lst
                                        .SelectMany(x => x.TransactionEntries)
                                        .Where(x => x.Item != null);
                        foreach (var item in layers[1].ToUpper().Split(' '))
                        {
                            // lst = lst.Where (x => x.SearchCriteria.ToUpper().Contains(item) == true).ToList();
                            var nlst = new List<TransactionEntryBase>();
                            if (layers[0] == "")
                            {
                                nlst = db.TransactionBase.OfType<Prescription>()
                                           .SelectMany(x => x.TransactionEntries)
                                           .Where(x => x.Item.Description.ToUpper().Contains(item.ToUpper()))
                                           .ToList();
                            }
                            else
                            {
                                nlst = plst.Take(1000).Where(x => x.Item.Description.ToUpper().Contains(item.ToUpper())).ToList();
                            }

                            //if (nlst.Any())
                            plst = nlst;

                        }
                        //if (plst.Any())
                        //{
                        lst = plst.Select(x => x.Transaction as Prescription)
                                      .Distinct().ToList();
                        //}
                    }

                    SearchResults = new ObservableCollection<object>(lst.OrderByDescending(x => x.Time));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        static ObservableCollection<object> _searchResults;
        [MyExceptionHandlerAspect]
        public ObservableCollection<object> SearchResults
        {
            get
            {
                return _searchResults;
            }
            set
            {
                _searchResults = value;
                RaisePropertyChanged(() => SearchResults);
            }
        }

        //+ ToDo: Replace this with your own data fields
        private RMSDataAccessLayer.TransactionBase transactionData;
        [MyExceptionHandlerAspect]
        public RMSDataAccessLayer.TransactionBase TransactionData
        {
            get { return transactionData; }
            set
            {
                try
                {
                    if (!object.Equals(transactionData, value))
                    {
                        transactionData = value;

                       SalesRegion.SalesVM.transactionData = value;
                       SalesRegion.SalesVM.OnStaticPropertyChanged("TransactionData");
                       if (SalesRegion.SalesVM.transactionData != null)
                       {
                           SalesRegion.SalesVM.rms.Attach(SalesRegion.SalesVM.transactionData);
                       }
                       this.regionManager.Regions["HeaderRegion"].Context = transactionData;
                       this.regionManager.Regions["CenterRegion"].Context = transactionData;
                        RaisePropertyChanged(() => TransactionData);

                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
}
