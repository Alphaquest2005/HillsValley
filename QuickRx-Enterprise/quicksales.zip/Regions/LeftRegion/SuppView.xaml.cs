﻿using Microsoft.Practices.Prism;
using Microsoft.Practices.Prism.Regions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RMSDataAccessLayer;
using System.Threading;

namespace LeftRegion
{
    /// <summary>
    /// Interaction logic for TransactionView.xaml
    /// </summary>
    public partial class SuppView : UserControl
    {
        public SuppView(SuppVM suppVM)
        {
            InitializeComponent();

            // Setup the view model context
            DataContext = suppVM;
            tvm = suppVM;
           

        }
        private SuppVM tvm;
        private void SearchPatient(object sender, RoutedEventArgs e)
        {

        }

        private void SearchMedication(object sender, RoutedEventArgs e)
        {

        }

        private void SearchDoctor(object sender, RoutedEventArgs e)
        {

        }

        private void SearchPrescriptions(object sender, RoutedEventArgs e)
        {

        }

        private void TextBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                tvm.SearchResults = new System.Collections.ObjectModel.ObservableCollection<object>() { "Searching" };
                
                if (Application.Current != null)
                    Application.Current.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new ThreadStart(delegate { }));
                tvm.SearchText = SearchBox.Text;
            }
        }

        private void AutoRepeatBtn_Click(object sender, RoutedEventArgs e)
        {
            tvm.TransactionData = (TransactionBase)(sender as FrameworkElement).DataContext;
            tvm.AutoRepeat();
        }

        private void Expander_Expanded(object sender, RoutedEventArgs e)
        {

           tvm.TransactionData = (TransactionBase)(sender as FrameworkElement).DataContext;
        }

        private void NewPrescription(object sender, RoutedEventArgs e)
        {
            tvm.TransactionData = (TransactionBase)(sender as FrameworkElement).DataContext;
            tvm.CopyPrescription();
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            SalesRegion.SalesVM.ShowInactiveItems = true;
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            SalesRegion.SalesVM.ShowInactiveItems = false;
        }

       

       

    }
}
