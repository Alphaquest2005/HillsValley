﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace RMSDataAccessLayer
{
    public partial class PrescriptionEntry : ISearchItem
    {
        public PrescriptionEntry()
        {
            PropertyChanged += PrescriptionEntry_PropertyChanged;
            //Dosage = "";
           
            ItemReference.AssociationChanged += ItemReference_AssociationChanged;
       
        }

        

        private void ItemReference_AssociationChanged(object sender, System.ComponentModel.CollectionChangeEventArgs e)
        {
            if (e.Action == System.ComponentModel.CollectionChangeAction.Add)
            {
                if (Item != null && typeof(Medicine).IsInstanceOfType(Item))
                {
                    if (Dosage == null) Dosage = ((Medicine)Item).SuggestedDosage;
                    if (ExpiryDate == null || ExpiryDate == "") ExpiryDate = ((Medicine)Item).ExpiryDate;
                    if (Repeat == null)    Repeat = 0;
                   
                }
            }
            OnPropertyChanged("DosageList");
        }

        private static object _syncLock = new object();

        public IEnumerable<string> DosageList
        {
            get
            {
                if (Item != null)
                {
                    if (Item != null)
                    {
                        var list = (from p in Item.TransactionEntryBase.OfType<PrescriptionEntry>().AsEnumerable()
                                   where p.ItemId == Item.ItemId
                                   select p.Dosage).Distinct();

                        BindingOperations.EnableCollectionSynchronization(list, _syncLock);

                        return list;
                    }
                }
                
                    return null;
            }
        }

        partial void OnDosageChanging(global::System.String value)
        {
            //if (value == "")
            //{
            //    AddError("Dosage", "Please Enter Dosage");
            //}
            //else
            //{
            //    RemoveError("Dosage");
            //}
        }

        void PrescriptionEntry_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Price")
            {
                // auto change price of items
                if (Item != null)
                {
                    Item.Price = Price;
                }
            }

            if (e.PropertyName == "ExpiryDate")
            {
                // auto change price of items
                if (Item != null && typeof(Medicine).IsInstanceOfType(Item))
                {
                   ((Medicine)Item).ExpiryDate = ExpiryDate;
                }
            }
        
            
            //if (Transaction != null)
            //{
            //    if (Dosage == null && Transaction.Status != "Please Enter Dosage")
            //    {
                    
            //        Transaction.Status = "Please Enter Dosage";
            //    }
            //    else
            //    {
            //        Transaction.Status = null;
            //    }
            //}
        }

        public string TransactionEntryNumber
        {
            get
            {
                string value = Transaction.TransactionNumber;
                if (value != null && value.ToString().Replace("0", "") != "")
                    value = value.ToString().Remove(0, value.ToString().IndexOfAny("123456789".ToCharArray()));
                if (EntryNumber == null)
                {
                    return value;
                }
                else
                {
                    return value + "-" + EntryNumber.ToString();
                }
            }
        }


        #region ISearchItem Members

        public string SearchCriteria
        {
            get
            {
                return Item.DisplayName + "|";
            }
            set
            {
               
            }
        }

        public string DisplayName
        {
            get { return this.Item.DisplayName; }
        }

        public string Key
        {
            get { return TransactionEntryNumber; }
        }

        #endregion
    }
}
