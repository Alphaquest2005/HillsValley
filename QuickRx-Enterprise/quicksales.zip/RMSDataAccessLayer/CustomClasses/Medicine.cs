﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RMSDataAccessLayer
{
   public partial class Medicine
    {

       public decimal PriceEx
       {
           get
           {
               if (QBInventoryItem != null)
               {
                   return System.Convert.ToDecimal(QBInventoryItem.Price);
               }
               else
               {
                   return Price;
               }
           }      

       }
       public bool VATEx
       {
           get
           {
               if (QBInventoryItem != null)
               {
                   return (QBInventoryItem.TaxCode == "VAT");
               }
               else
               {
                   return (SalesTax > 0);
               }
           }
       }
        public double QuantityEx
        {
            get
            {
                if (QBInventoryItem != null)
               {
                   return System.Convert.ToDouble(QBInventoryItem.Quantity) ;
               }
               else
               {
                   return System.Convert.ToDouble(Quantity);
               }
            }
        }

       

    }
}
