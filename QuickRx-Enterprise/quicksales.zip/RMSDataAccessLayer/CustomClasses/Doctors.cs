﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RMSDataAccessLayer
{
    public partial class Doctor
    {

        
        public new string SearchCriteria
        {
            get
            {
                return string.Format("d:{0} {1}",DisplayName, Code);
            }
            set
            {
                
            }
        }

        public new string DisplayName
        {
            get {
                if (FirstName.IndexOf("Dr ") == -1 && FirstName.IndexOf("Dr.") == -1)
                {
                    return "Dr. " + " " + FirstName + " " + LastName;
                }
                else
                {
                    return FirstName.Replace("Dr ", "Dr. ") + " " + LastName;
                }
            
            }// base.Salutation + " " +
        }


    }
}
