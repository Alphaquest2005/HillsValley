SET IDENTITY_INSERT [dbo].[CustomerSet] ON
INSERT INTO [dbo].[CustomerSet] ([CustomerId], [FirstName], [LastName], [CompanyName]) VALUES (1, N'Kellon', N'Rubin', N'Port')
SET IDENTITY_INSERT [dbo].[CustomerSet] OFF
