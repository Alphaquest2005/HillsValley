SET IDENTITY_INSERT [dbo].[Company] ON
INSERT INTO [dbo].[Company] ([Id], [CompanyName], [Address], [SoftwareName]) VALUES (1, N'GrenReal', N'St. George''s', N'QicTick')
SET IDENTITY_INSERT [dbo].[Company] OFF
