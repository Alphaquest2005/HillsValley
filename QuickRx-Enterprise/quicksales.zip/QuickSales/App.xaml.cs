﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Windows;
using RMSDataAccessLayer;

namespace QuickSales
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        //public App()
        //{
        //    this.ShutdownMode = ShutdownMode.OnMainWindowClose;
        //    Bootstrapper bootstrapper = new Bootstrapper();
        //    bootstrapper.Run();
        //}
        static RMSModel db = new RMSModel();
        private bool Authenticate(string user, string pass)
        {
           
            var cashier = (from c in db.Persons.OfType<Cashier>()
                           where c.LoginName == user
                           select c).FirstOrDefault();

            if (cashier != null && cashier.SPassword == pass)
            {
                return LogIn(cashier);
            }
            else
            {
                return false;
            }

        }
        public static Cashier _cashier = null;
        public static Cashier Cashier
        {
            get
            {
                return _cashier;
            }
        }
        private static bool LogIn(Cashier cashier)
        {
           
            _cashier = cashier;

            CashierLog log = db.CashierLogs.Where(x => x.PersonId == cashier.Id && x.MachineName == Environment.MachineName).AsEnumerable().LastOrDefault();
            if (log != null)
            {
                LogOut(cashier);
            }
            SalesRegion.SalesVM._cashierEx = cashier;
                log = db.CreateObject<CashierLog>();
                log.LoginTime = DateTime.Now;
                log.Status = "LogIn";
                db.CashierLogs.AddObject(log);

            

            log.PersonId = cashier.Id;
            log.MachineName = Environment.MachineName;


            //db = null;

            db.SaveChanges();
          //  db.Dispose();
            return true;
        }


        private static bool LogOut(Cashier cashier)
        {
            if (cashier == null) return false;
            SalesRegion.SalesVM.SaveDatabase1();
            _cashier = cashier;
            CashierLog log = db.CashierLogs.Where(x => x.PersonId == cashier.Id && x.MachineName == Environment.MachineName).AsEnumerable().LastOrDefault();

            if (log.Status == "LogIn")
            {
                log.LogoutTime = DateTime.Now;
                log.Status = "LogOut";



                log.PersonId = cashier.Id;
                log.MachineName = Environment.MachineName;


                //db = null;

                db.SaveChanges();

                //db.Dispose(); 
                return true;
            }
            return false;
        }
        /// <summary>
        /// Creates a new instance of <c>App</c>
        /// </summary>
        public App()
        {
            Application.Current.ShutdownMode = ShutdownMode.OnExplicitShutdown;
            LoginRoutine();
            Application.Current.Exit += OnApplicationExit;
        }

        private void OnApplicationExit(object sender, ExitEventArgs e)
        {
            LogOut(_cashier);
        }

        public  void LoginRoutine()
        {
            LogInScreen logon = new LogInScreen();
#if DEBUG
            logon.HintVisible = true;
#endif
            bool? res = logon.ShowDialog();
            if (!res ?? true)
            {
                Shutdown(1);
            }
            else 
                if (Authenticate(logon.UserName, logon.Password))
            {
                //StartupContainer();
                LogInScreen logon1 = new LogInScreen();
                logon1.Show();
                logon1.ShowOptions();
            }
            else
            {
                MessageBox.Show(
                    "Application is exiting due to invalid credentials",
                    "Application Exit",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                Shutdown(1);
            }
        }

        private void StartupContainer()
        {
            Application.Current.ShutdownMode = ShutdownMode.OnExplicitShutdown;
            
            Application.Current.MainWindow = null;

            Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
            Bootstrapper bootStrapper = new Bootstrapper();
            bootStrapper.Run();

           
        }
    }
}
