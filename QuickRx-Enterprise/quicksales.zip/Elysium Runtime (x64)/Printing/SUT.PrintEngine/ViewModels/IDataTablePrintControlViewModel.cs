namespace SUT.PrintEngine.ViewModels
{
    public interface IDataTablePrintControlViewModel : IItemsPrintControlViewModel
    {
        
    }
}