﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesServiceObjects
{
    //+ This file and class should be replaced with your client side business objects.
    //+ Any object received from a Web Service should be converted into an object that 
    //+ exists in this project.
    public class ExampleObject
    {

    }
}
