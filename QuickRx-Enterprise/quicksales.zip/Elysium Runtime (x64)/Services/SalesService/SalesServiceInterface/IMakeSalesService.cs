﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesServiceInterface
{
    public interface IMakeSalesService
    {
        //+ ToDo: Replace this with the published methods of your prism service.
        bool SaveTransaction(string parameter);
    }
}
